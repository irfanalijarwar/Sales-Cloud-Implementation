/*
*********************************************************
LWC Component Name : JRST_BicycleRevenueTableCmp
Created Date       : August 30, 2024
@description       : This Lightning Web Component (LWC) is used to display a 
                     table of aggregated bicycle revenue data for a specific account.
                     It subscribes to a Platform Event to update the data in real-time
                     when changes occur in the related Bicycle records.
@author            : Irfan Ali
Modification Log:
Ver   Date         Author                         Modification
1.0   08-30-2024   Irfan Ali                      Initial Version
1.1   08-31-2024   Irfan Ali                      Implemented sorting
1.2   09-01-2024   Irfan Ali                      Implemented Platform event to auto refresh the data-table.
*********************************************************
*/

import { LightningElement, wire, api, track } from 'lwc';
import { subscribe, unsubscribe, onError, setDebugFlag } from 'lightning/empApi';
import fetchBicycleRevenues from '@salesforce/apex/JRST_BicycleRevenueController.fetchBicycleRevenues';
import { refreshApex } from '@salesforce/apex';

export default class JRST_BicycleRevenueTableCmp extends LightningElement {
    @api recordId;
    @track bicycleRevenues = [];
    wiredBicycleRevenues;
    subscription = {};
    defaultSortDirection = 'asc';
    sortDirection = 'asc';
    sortedBy;
    channelName = '/event/Bicycle_Added__e'; // Name of the Platform Event channel

    // Define the columns for the lightning-datatable
    columns = [
        { label: 'Brand', fieldName: 'brand', type: 'text', sortable: true, cellAttributes: { alignment: 'center' } },
        { label: 'Model', fieldName: 'model', type: 'text', sortable: true, cellAttributes: { alignment: 'center' } },
        { label: 'First Registration Date', fieldName: 'firstRegDate', type: 'date', sortable: true, cellAttributes: { alignment: 'center' } },
        { label: 'Total Revenue', fieldName: 'totalRevenue', type: 'currency', sortable: true, cellAttributes: { alignment: 'center' } }
    ];

    /*
    *********************************************************
    @Method Name    : loadBicycleRevenues
    @description    : This method is wired to fetchBicycleRevenues Apex method and 
                      loads the bicycle revenue data for the given account.
    @param          : result - The result of the wire service, containing either data or an error.
    @return         : void
    ********************************************************
    */

    @wire(fetchBicycleRevenues, { accountId: '$recordId' })
    loadBicycleRevenues(result) {
        this.wiredBicycleRevenues = result;
        if (result.data) {
            this.bicycleRevenues = result.data.map((record, index) => ({
                ...record,
                id: index + 1
            }));
            this.sortData(this.sortedBy, this.sortDirection);
        } else if (result.error) {
            console.error('Error fetching bicycle revenue data', result.error);
        }
    }

    connectedCallback() {
        this.subscribeToEvent();
    }

    /*
    *********************************************************
    @Method Name    : subscribeToEvent
    @description    : Subscribes to the Bicycle_Added__e Platform Event channel to 
                      receive updates when a related Bicycle record is added, updated, 
                      or deleted for the current account. It triggers the refreshData 
                      method to update the bicycle revenue data.
    @param          : None
    @return         : void
    ********************************************************
    */

    subscribeToEvent() {
        const messageCallback = (response) => {
            const event = response.data.payload;
            if (event.AccountId__c === this.recordId) {
                this.refreshData();
            }
        };
    
        new Promise((resolve, reject) => {
            subscribe(this.channelName, -1, messageCallback, (response) => {
                if (response) {
                    resolve(response);
                } else {
                    reject('Failed to subscribe');
                }
            });
        })
        .then((response) => {
            this.subscription = response;
        })
        .catch((error) => {
            console.error('Error subscribing to Platform Event: ', error);
        });
    
        // Enable debug logging for the empApi
        setDebugFlag(true);
    
        // Register error listener for the empApi
        onError((error) => {
            console.error('Received error from empApi: ', error);
        });
    }

    /*
    *********************************************************
    @Method Name    : refreshData
    @description    : Refreshes the bicycle revenue data by calling the refreshApex 
                      function on the wired result to fetch the latest data from the server.
    @param          : None
    @return         : void
    ********************************************************
    */

    refreshData() {
        return refreshApex(this.wiredBicycleRevenues);
    }

    /*
    *********************************************************
    @Method Name    : disconnectedCallback
    @description    : Unsubscribes from the Platform Event channel when the component 
                      is disconnected from the DOM to prevent memory leaks.
    @param          : None
    @return         : void
    ********************************************************
    */
   
    disconnectedCallback() {
        unsubscribe(this.subscription, response => {
            console.log('Unsubscribed from event channel:', response);
        });
    }

    /*
    *********************************************************
    @Method Name    : onHandleSort
    @description    : Handles the sorting event triggered by the user in the lightning 
                      data-table and sorts the bicycle revenue data accordingly.
    @param          : event - The event object containing details about the sorting 
                              criteria, including the field name and sort direction.
    @return         : void
    ********************************************************
    */

    onHandleSort(event) {
        const { fieldName: sortedBy, sortDirection } = event.detail;
        this.sortDirection = sortDirection;
        this.sortedBy = sortedBy;
        this.sortData(sortedBy, sortDirection);
    }

    /*
    *********************************************************
    @Method Name    : sortData
    @description    : Sorts the bicycle revenue data based on the specified field name 
                      and sort direction (ascending or descending). Handles null values 
                      to ensure accurate sorting.
    @param          : fieldname - The name of the field to sort by.
    @param          : direction - The direction of the sort ('asc' for ascending, 
                                  'desc' for descending).
    @return         : void
    ********************************************************
    */

    sortData(fieldname, direction) {
        let parseData = JSON.parse(JSON.stringify(this.bicycleRevenues));
        let keyValue = (a) => {
            return a[fieldname];
        };
        let isReverse = direction === 'asc' ? 1 : -1;
        parseData.sort((x, y) => {
            x = keyValue(x) ? keyValue(x) : ''; // handling null values
            y = keyValue(y) ? keyValue(y) : '';
            return isReverse * ((x > y) - (y > x));
        });
        this.bicycleRevenues = parseData;
    }
}