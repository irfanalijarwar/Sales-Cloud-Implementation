import { createElement } from 'lwc';
import JRST_BicycleRevenueTableCmp from 'c/jRST_BicycleRevenueTableCmp';
import fetchBicycleRevenues from '@salesforce/apex/JRST_BicycleRevenueController.fetchBicycleRevenues';
import mockFetchBicycleRevenues from './__mocks__/wireAdapter.json';

// Mock the Apex wire adapter
jest.mock(
    '@salesforce/apex/JRST_BicycleRevenueController.fetchBicycleRevenues',
    () => {
        const { createApexTestWireAdapter } = require('@salesforce/sfdx-lwc-jest');
        return {
            default: createApexTestWireAdapter(jest.fn())
        };
    },
    { virtual: true }
);

describe('c-jRST-BicycleRevenueTableCmp', () => {
    afterEach(() => {
        // Reset the DOM after each test
        while (document.body.firstChild) {
            document.body.removeChild(document.body.firstChild);
        }
        jest.clearAllMocks();
    });

    // Helper function to wait until the microtask queue is empty
    async function flushPromises() {
        return Promise.resolve();
    }

    it('renders the bicycle revenues correctly', async () => {
        const element = createElement('c-jRST-BicycleRevenueTableCmp', {
            is: JRST_BicycleRevenueTableCmp,
        });
        document.body.appendChild(element);

        // Emit the mock data via the wire adapter
        fetchBicycleRevenues.emit(mockFetchBicycleRevenues);

        // Wait for any asynchronous DOM updates
        await flushPromises();

        // Access the datatable after it's rendered
        const datatable = element.shadowRoot.querySelector('lightning-datatable');
        expect(datatable).not.toBeNull();
        const rows = datatable.data;

        // Verify that the number of rows matches the mock data
        expect(rows.length).toBe(mockFetchBicycleRevenues.length);

        // Verify the data in the first row
        expect(datatable.data[0].brand).toBe('Brand B');
        expect(datatable.data[0].model).toBe('Model Y');
        expect(datatable.data[0].firstRegDate).toBe('2022-05-10');
        expect(datatable.data[0].totalRevenue).toBe(2000);
    });

    it('sorts the data correctly when onsort is triggered', async () => {
        const element = createElement('c-jRST_BicycleRevenueTableCmp', {
            is: JRST_BicycleRevenueTableCmp,
        });
        document.body.appendChild(element);

        // Emit the mock data via the wire adapter
        fetchBicycleRevenues.emit(mockFetchBicycleRevenues);

        // Wait for any asynchronous DOM updates
        await flushPromises();

        // Access the datatable after it's rendered
        const datatable = element.shadowRoot.querySelector('lightning-datatable');
        expect(datatable).not.toBeNull();

        // Dispatch onsort event to sort by brand in ascending order
        datatable.dispatchEvent(
            new CustomEvent('sort', {
                detail: { fieldName: 'brand', sortDirection: 'asc' },
            })
        );

        // Wait for any asynchronous DOM updates after sort
        await flushPromises();

        // Verify the data in the first row after sorting
        expect(datatable.data[0].brand).toBe('Brand A');
        expect(datatable.data[0].model).toBe('Model X');
        expect(datatable.data[0].firstRegDate).toBe('2023-01-15');
        expect(datatable.data[0].totalRevenue).toBe(1500);
    });
});