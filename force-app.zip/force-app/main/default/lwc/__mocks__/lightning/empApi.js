let callback;

export const subscribe = jest.fn().mockImplementation((channel, replayId, eventCallback) => {
    callback = eventCallback;
    return Promise.resolve({ id: 'mockedSubscriptionId', channel });
});

export const unsubscribe = jest.fn();

export const onError = jest.fn();

export const setDebugFlag = jest.fn();

export const jestMockPublish = (channel, message) => {
    return new Promise((resolve) => {
        if (callback) {
            callback(message);
            resolve();
        }
    });
};