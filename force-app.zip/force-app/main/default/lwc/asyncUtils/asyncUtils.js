// asyncUtils.js
/**
 * Utility function to wait for all promises to resolve.
 * This is useful in Jest tests to ensure all asynchronous operations are complete.
 * @returns {Promise} A promise that resolves after all other promises have been resolved.
 */
export function flushPromises() {
    return new Promise((resolve) => setImmediate(resolve));
}