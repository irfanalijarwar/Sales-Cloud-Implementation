module.exports = {
    moduleNameMapper: {
        '^lightning/empApi$': '<rootDir>/force-app/main/default/lwc/__mocks__/lightning/empApi'
    },
    moduleFileExtensions: ['js', 'json', 'html'],
    transformIgnorePatterns: ['<rootDir>/node_modules/'],
    testEnvironment: 'jsdom',
    setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
};